import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { WellnessHeader } from "@/components/WellnessHeader";
import { HeroSection } from "@/components/HeroSection";
import { WellnessDashboard } from "@/components/WellnessDashboard";
import NotFound from "@/pages/not-found";
import { useState } from 'react';

function Home() {
  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      <div className="container py-16">
        <WellnessDashboard />
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeProvider defaultTheme="light">
          <div className="min-h-screen bg-background text-foreground">
            <WellnessHeader onMenuClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} />
            <main>
              <Router />
            </main>
          </div>
          <Toaster />
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
