import { ArrowRight, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import heroImage from '@assets/generated_images/Wellness_hero_illustration_6d0c4fed.png'

export function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-transparent" />
      <div className="container relative py-16 lg:py-24">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-medium text-accent-foreground">
              <Sparkles className="h-4 w-4" />
              AI-Powered Wellness Platform
            </div>
            
            <div className="space-y-4">
              <h1 className="text-4xl font-bold tracking-tight text-foreground lg:text-6xl">
                Balance Your
                <span className="text-primary"> Hormones</span>,
                Transform Your Life
              </h1>
              <p className="text-xl text-muted-foreground max-w-lg">
                Build sustainable daily routines that support hormonal balance and reproductive health with personalized AI recommendations.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="group" data-testid="button-get-started">
                Get Started Today
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button variant="outline" size="lg" data-testid="button-learn-more">
                Learn More
              </Button>
            </div>
            
            <div className="flex items-center gap-6 pt-4">
              <div className="text-sm text-muted-foreground">
                <div className="font-semibold text-foreground">10,000+</div>
                Women supported
              </div>
              <div className="text-sm text-muted-foreground">
                <div className="font-semibold text-foreground">95%</div>
                Report improvements
              </div>
              <div className="text-sm text-muted-foreground">
                <div className="font-semibold text-foreground">Science-based</div>
                Recommendations
              </div>
            </div>
          </div>
          
          <div className="relative">
            <Card className="overflow-hidden border-0 shadow-xl">
              <img 
                src={heroImage} 
                alt="Wellness illustration representing balance and harmony" 
                className="w-full h-auto object-cover"
              />
            </Card>
            <div className="absolute -top-4 -right-4 w-8 h-8 bg-accent rounded-full animate-pulse" />
            <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-primary rounded-full animate-pulse delay-1000" />
          </div>
        </div>
      </div>
    </section>
  )
}