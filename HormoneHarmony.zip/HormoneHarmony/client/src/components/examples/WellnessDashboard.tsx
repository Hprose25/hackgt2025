import { WellnessDashboard } from '../WellnessDashboard'
import { ThemeProvider } from '../ThemeProvider'

export default function WellnessDashboardExample() {
  return (
    <ThemeProvider>
      <div className="p-4">
        <WellnessDashboard />
      </div>
    </ThemeProvider>
  )
}