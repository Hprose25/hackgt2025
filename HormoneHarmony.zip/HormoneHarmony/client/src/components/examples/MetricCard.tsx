import { MetricCard } from '../MetricCard'
import { ThemeProvider } from '../ThemeProvider'
import { Moon, Droplets } from 'lucide-react'
import { useState } from 'react'

export default function MetricCardExample() {
  const [sleepValue, setSleepValue] = useState(7.5)
  const [hydrationValue, setHydrationValue] = useState(6)

  return (
    <ThemeProvider>
      <div className="p-4 grid gap-4 md:grid-cols-2 max-w-2xl">
        <MetricCard
          icon={Moon}
          title="Sleep Quality"
          description="Hours of restful sleep"
          value={sleepValue}
          onChange={setSleepValue}
          unit=" hrs"
          color="primary"
          suggestions={[
            "Try a warm bath before bed",
            "Keep bedroom cool and dark",
            "Avoid caffeine after 2 PM"
          ]}
        />
        
        <MetricCard
          icon={Droplets}
          title="Hydration"
          description="Daily water intake"
          value={hydrationValue}
          onChange={setHydrationValue}
          unit=" glasses"
          color="accent"
          suggestions={[
            "Start your day with water and lemon",
            "Herbal teas count too",
            "Eat water-rich foods"
          ]}
        />
      </div>
    </ThemeProvider>
  )
}