import { ThemeProvider } from '../ThemeProvider'
import { ThemeToggle } from '../ThemeToggle'

export default function ThemeProviderExample() {
  return (
    <ThemeProvider>
      <div className="p-4 space-y-4">
        <h3 className="text-lg font-semibold">Theme Provider Example</h3>
        <p className="text-muted-foreground">Toggle between light and dark modes</p>
        <ThemeToggle />
      </div>
    </ThemeProvider>
  )
}