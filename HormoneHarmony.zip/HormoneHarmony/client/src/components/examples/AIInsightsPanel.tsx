import { AIInsightsPanel } from '../AIInsightsPanel'
import { ThemeProvider } from '../ThemeProvider'

export default function AIInsightsPanelExample() {
  return (
    <ThemeProvider>
      <div className="p-4 max-w-lg">
        <AIInsightsPanel />
      </div>
    </ThemeProvider>
  )
}