import { CycleTracker } from '../CycleTracker'
import { ThemeProvider } from '../ThemeProvider'

export default function CycleTrackerExample() {
  return (
    <ThemeProvider>
      <div className="p-4 max-w-md">
        <CycleTracker />
      </div>
    </ThemeProvider>
  )
}