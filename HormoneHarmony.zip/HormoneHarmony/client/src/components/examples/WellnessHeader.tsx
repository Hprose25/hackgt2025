import { WellnessHeader } from '../WellnessHeader'
import { ThemeProvider } from '../ThemeProvider'

export default function WellnessHeaderExample() {
  return (
    <ThemeProvider>
      <div className="min-h-[200px]">
        <WellnessHeader onMenuClick={() => console.log('Menu clicked')} />
        <div className="p-4">
          <p className="text-muted-foreground">Header with navigation and theme toggle</p>
        </div>
      </div>
    </ThemeProvider>
  )
}