import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Calendar, Circle, Moon } from 'lucide-react'
import { useState } from 'react'

interface CycleData {
  currentDay: number
  cycleLength: number
  phase: 'menstrual' | 'follicular' | 'ovulation' | 'luteal'
  symptoms: string[]
  nextPrediction: string
}

export function CycleTracker() {
  // todo: remove mock functionality
  const [cycleData] = useState<CycleData>({
    currentDay: 14,
    cycleLength: 28,
    phase: 'ovulation',
    symptoms: ['Energy boost', 'Clear skin', 'Positive mood'],
    nextPrediction: 'Sept 15'
  })

  const getPhaseInfo = (phase: string) => {
    switch (phase) {
      case 'menstrual':
        return { color: 'bg-red-500', label: 'Menstrual', description: 'Rest and restore' }
      case 'follicular':
        return { color: 'bg-green-500', label: 'Follicular', description: 'Energy building' }
      case 'ovulation':
        return { color: 'bg-yellow-500', label: 'Ovulation', description: 'Peak fertility' }
      case 'luteal':
        return { color: 'bg-blue-500', label: 'Luteal', description: 'Prepare for rest' }
      default:
        return { color: 'bg-gray-500', label: 'Unknown', description: '' }
    }
  }

  const phaseInfo = getPhaseInfo(cycleData.phase)
  const progressPercentage = (cycleData.currentDay / cycleData.cycleLength) * 100

  return (
    <Card className="hover-elevate" data-testid="card-cycle-tracker">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Moon className="h-5 w-5 text-primary" />
          Cycle Tracking
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="relative">
          <div className="flex items-center justify-center w-32 h-32 mx-auto">
            <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="hsl(var(--border))"
                strokeWidth="3"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="hsl(var(--primary))"
                strokeWidth="3"
                fill="transparent"
                strokeDasharray={`${progressPercentage * 2.827} ${283 - progressPercentage * 2.827}`}
                className="transition-all duration-500 ease-in-out"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center flex-col">
              <span className="text-2xl font-bold text-foreground">Day {cycleData.currentDay}</span>
              <span className="text-sm text-muted-foreground">of {cycleData.cycleLength}</span>
            </div>
          </div>
        </div>

        <div className="text-center space-y-2">
          <Badge className={`${phaseInfo.color} text-white`} data-testid="badge-cycle-phase">
            {phaseInfo.label} Phase
          </Badge>
          <p className="text-sm text-muted-foreground">{phaseInfo.description}</p>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Next period:</span>
            <span className="font-medium text-foreground">{cycleData.nextPrediction}</span>
          </div>
          
          <div>
            <p className="text-sm font-medium text-foreground mb-2">Current symptoms:</p>
            <div className="flex flex-wrap gap-2">
              {cycleData.symptoms.map((symptom, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {symptom}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => console.log('Log symptom triggered')}
            data-testid="button-log-symptom"
          >
            <Circle className="h-3 w-3 mr-1" />
            Log Symptom
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => console.log('View calendar triggered')}
            data-testid="button-view-calendar"
          >
            <Calendar className="h-3 w-3 mr-1" />
            View Calendar
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}