import { Heart, Menu } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { ThemeToggle } from './ThemeToggle'

interface WellnessHeaderProps {
  onMenuClick?: () => void
}

export function WellnessHeader({ onMenuClick }: WellnessHeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={onMenuClick}
            data-testid="button-menu"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <Heart className="h-6 w-6 text-primary" />
          <span className="text-xl font-semibold text-foreground">Flourish</span>
        </div>
        
        <div className="flex flex-1 items-center justify-end gap-2">
          <nav className="hidden md:flex items-center gap-6">
            <Button variant="ghost" data-testid="link-dashboard">Dashboard</Button>
            <Button variant="ghost" data-testid="link-insights">Insights</Button>
            <Button variant="ghost" data-testid="link-resources">Resources</Button>
          </nav>
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}