import { MetricCard } from './MetricCard'
import { CycleTracker } from './CycleTracker'
import { AIInsightsPanel } from './AIInsightsPanel'
import { Moon, Droplets, Leaf, Activity, Heart, Zap } from 'lucide-react'
import { useState } from 'react'

export function WellnessDashboard() {
  // todo: remove mock functionality
  const [metrics, setMetrics] = useState({
    sleep: 7.5,
    hydration: 6.0,
    nutrition: 8.0,
    activity: 7.0,
    stress: 6.5,
    energy: 8.5
  })

  const updateMetric = (key: string, value: number) => {
    setMetrics(prev => ({ ...prev, [key]: value }))
    console.log(`Updated ${key} to ${value}`)
  }

  const wellnessTips = {
    sleep: [
      "Try a warm bath with lavender 30 minutes before bed",
      "Keep your bedroom between 65-68°F for optimal sleep",
      "Avoid screens 1 hour before bedtime for better sleep quality"
    ],
    hydration: [
      "Start your day with a glass of warm water and lemon",
      "Herbal teas like chamomile count toward your daily water intake",
      "Eat water-rich foods like cucumber, watermelon, and leafy greens"
    ],
    nutrition: [
      "Include healthy fats like avocado and nuts to support hormone production",
      "Eat protein with each meal to stabilize blood sugar",
      "Consider magnesium-rich foods like dark chocolate and spinach"
    ],
    activity: [
      "Gentle yoga during menstruation can ease cramps",
      "High-intensity workouts are best during ovulation",
      "Walking in nature reduces cortisol and supports mental health"
    ],
    stress: [
      "Practice deep breathing: 4 counts in, 6 counts out",
      "Try the 5-4-3-2-1 grounding technique when feeling overwhelmed",
      "Journaling for 5 minutes can help process daily stress"
    ],
    energy: [
      "Balance your meals with complex carbs, protein, and healthy fats",
      "Take a 10-minute walk outside for natural energy boost",
      "Consider adaptogenic herbs like ashwagandha for sustained energy"
    ]
  }

  return (
    <div className="space-y-8" data-testid="wellness-dashboard">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold text-foreground">Your Wellness Dashboard</h2>
        <p className="text-muted-foreground">Track your daily metrics and receive personalized insights</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <MetricCard
          icon={Moon}
          title="Sleep Quality"
          description="Hours of restful sleep"
          value={metrics.sleep}
          onChange={(value) => updateMetric('sleep', value)}
          unit=" hrs"
          color="primary"
          suggestions={wellnessTips.sleep}
        />
        
        <MetricCard
          icon={Droplets}
          title="Hydration"
          description="Daily water intake"
          value={metrics.hydration}
          onChange={(value) => updateMetric('hydration', value)}
          unit=" glasses"
          color="accent"
          suggestions={wellnessTips.hydration}
        />
        
        <MetricCard
          icon={Leaf}
          title="Nutrition"
          description="Overall diet quality"
          value={metrics.nutrition}
          onChange={(value) => updateMetric('nutrition', value)}
          unit="/10"
          color="secondary"
          suggestions={wellnessTips.nutrition}
        />
        
        <MetricCard
          icon={Activity}
          title="Activity Level"
          description="Physical movement"
          value={metrics.activity}
          onChange={(value) => updateMetric('activity', value)}
          unit="/10"
          color="primary"
          suggestions={wellnessTips.activity}
        />
        
        <MetricCard
          icon={Heart}
          title="Stress Level"
          description="Mental wellbeing"
          value={metrics.stress}
          onChange={(value) => updateMetric('stress', value)}
          unit="/10"
          color="accent"
          suggestions={wellnessTips.stress}
        />
        
        <MetricCard
          icon={Zap}
          title="Energy Level"
          description="Overall vitality"
          value={metrics.energy}
          onChange={(value) => updateMetric('energy', value)}
          unit="/10"
          color="secondary"
          suggestions={wellnessTips.energy}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <CycleTracker />
        <AIInsightsPanel />
      </div>
    </div>
  )
}