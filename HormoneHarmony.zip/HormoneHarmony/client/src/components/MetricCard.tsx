import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { useState } from 'react'
import { LucideIcon } from 'lucide-react'

interface MetricCardProps {
  icon: LucideIcon
  title: string
  description: string
  value: number
  onChange: (value: number) => void
  unit?: string
  color?: 'primary' | 'secondary' | 'accent'
  suggestions?: string[]
}

export function MetricCard({ 
  icon: Icon, 
  title, 
  description, 
  value, 
  onChange, 
  unit = '',
  color = 'primary',
  suggestions = []
}: MetricCardProps) {
  const [localValue, setLocalValue] = useState(value)

  const handleSliderChange = (newValues: number[]) => {
    setLocalValue(newValues[0])
    onChange(newValues[0])
  }

  const getValueColor = (val: number) => {
    if (val >= 8) return 'text-green-600 dark:text-green-400'
    if (val >= 6) return 'text-yellow-600 dark:text-yellow-400'
    return 'text-red-600 dark:text-red-400'
  }

  const getValueLabel = (val: number) => {
    if (val >= 8) return 'Excellent'
    if (val >= 6) return 'Good'
    if (val >= 4) return 'Fair'
    return 'Needs attention'
  }

  return (
    <Card className="hover-elevate" data-testid={`card-metric-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <Icon className={`h-4 w-4 ${color === 'primary' ? 'text-primary' : color === 'accent' ? 'text-accent' : 'text-secondary'}`} />
          {title}
        </CardTitle>
        <Badge variant="outline" className="text-xs">
          {getValueLabel(localValue)}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">{description}</span>
            <span className={`text-2xl font-bold ${getValueColor(localValue)}`}>
              {localValue}{unit}
            </span>
          </div>
          
          <Slider
            value={[localValue]}
            onValueChange={handleSliderChange}
            max={10}
            min={1}
            step={0.5}
            className="w-full"
            data-testid={`slider-${title.toLowerCase().replace(/\s+/g, '-')}`}
          />
        </div>
        
        {suggestions.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground">Today's tip:</p>
            <p className="text-sm bg-accent/20 rounded-md p-2 border-l-2 border-accent">
              {suggestions[Math.floor(Math.random() * suggestions.length)]}
            </p>
          </div>
        )}
        
        <Button 
          variant="ghost" 
          size="sm" 
          className="w-full" 
          onClick={() => console.log(`Logging ${title}: ${localValue}${unit}`)}
          data-testid={`button-log-${title.toLowerCase().replace(/\s+/g, '-')}`}
        >
          Log Details
        </Button>
      </CardContent>
    </Card>
  )
}